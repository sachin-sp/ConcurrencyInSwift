import Foundation
import UIKit
import Concurrency_Sources

/*
 1. What is Concurrency
 2. Why Concurrency
 3. Concurrency vs Parallelism
    - Time slicing
    - Context Switch
    - Multi Core CPUs
 4. How to acheive Concurrency
    - Multithreading (creating thread manually)
    - Multithreading (recommended ways)
      - GCD
      - OPeration Queues
      - Task
      - Task Groups
      - Actors
 5. GCD
 6. Synchronous vs Asynchronous Operations
 7. Sync vs Serial & Async vs Concurrent
 8. Queues
    - Serial
    - Concurrent
    - System Provided
    - Custom
      - Target Queue
      - Dispatch Group
      - Dispatch Work Item
      - Dispatch Barrier
      - Dispatch Semaphore
      - Dispatch Sources
      - Operation
      - Operation Queue
 9. Concurerncy in Swift 5.6
    - Task
    - Task Group
    - Actors
    - Async Await
 */

//let customThread = CustomThread()
//customThread.createThread()
//
//let asyncDispatchQueue = AsyncDispatchQueue()
//asyncDispatchQueue.test()

//let asyncConcurrent = AsyncConcurrent()
//asyncConcurrent.test()

//let asyncSerial = AsyncSerial()
//asyncSerial.test()

//let syncConcurrent = SyncConcurrent()
//syncConcurrent.test()

//let synSerial = SyncSerial()
//synSerial.test()

//let targetgetQueue = TargetQueue()
//targetgetQueue.test2()


//let qos = QosTest()
//qos.test()

//let dispatchGroupTest = DispatchGroupTest()
//dispatchGroupTest.test()

//let dispatchWorkItemTest = DispatchWorkItemTest()
//dispatchWorkItemTest.test()

//let dispatchBarrierFlag = DispatchBarrierFlag()
//dispatchBarrierFlag.test()

//let dispatchSemaphoreTest = DispatchSemaphoreTest()
//dispatchSemaphoreTest.test()

//let operationTest = OperationTest()
//operationTest.testCustomAsyncOperation()

let actorsAsyncAwaitTest = ActorsAsyncAwaitTest()
//actorsAsyncAwaitTest.testRaceConditionWithClass()
actorsAsyncAwaitTest.testRaceConditionWithActor()
