import Foundation

/*
 .inherit
   Inherit from target queue (default behaviour)
 .workItem
   Individual auto release pool
 .never
   Never setup an individual auto release pool
 */
